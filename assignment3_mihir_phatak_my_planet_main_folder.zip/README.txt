Please use following command to compile the c file assignment3_mihir_phatak_my_planet.c :

gcc assignment3_mihir_phatak_my_planet.c -lGL -lGLU -lglut -o assignment3_mihir_phatak_my_planet

Run as ./assignment3_mihir_phatak_my_planet
